#include "kb.h"
#include "config.h"

#define _BL 0

const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {
	/*
	 * ,---------------------------.
	 * | NUMLK|  /   |  *   |  -   |  
	 * |------+------+------+------|
	 * |   7  |  8   |  9   |      |
	 * |------+------+------+  +   |
	 * |   4  |  5   |  6   |      |
	 * |------+------+------+------|
	 * |   1  |  2   |  3   |      |
	 * |------+------+------| ENT  |
	 * |   0         |  .   |      |
	 * |---------------------------|

	*/

	[_BL]=LAYOUT_egpad(
		KC_NLCK, KC_PSLS, KC_PAST, KC_PMNS, KC_A,
		KC_P7, KC_P8, KC_P9, KC_PPLS, KC_B,
		KC_P4, KC_P5, KC_P6, KC_PENT, KC_C,
		KC_P1, KC_P2, KC_P3, 
		KC_P0, KC_PDOT),
};

/*enum custom_keycodes {
	FOOPAUSE = SAFE_RANGE;
}

bool process_record_user(uint16_t keycode, keyrecord_t *record) {
    switch (keycode) {
    	case FOOPAUSE:
    		if (record->event.pressed){
    			SEND_STRING()
    		}*/

bool encoder_update_user(uint8_t index, bool clockwise){
	if (index==0) {/*First Encoder*/
		if (clockwise){
			 tap_code(KC_AUDIO_VOL_UP);
        } else {
             tap_code(KC_AUDIO_VOL_DOWN);
        }
	} else if (index==1) {/*Second Encoder*/
			if (clockwise){
			 tap_code(KC_RIGHT);
        } else {
             tap_code(KC_LEFT);
        }
	} else if (index==2) {/*Third Encoder*/
			if (clockwise){
			 tap_code(KC_DOWN);
        } else {
             tap_code(KC_UP);
        }
    }return true;	
}